#include<stdio.h>
void main()

{
    float net_salary, gross_salary,allowance,deduction;
    printf("Enter Gross salary:");
    scanf("%f", &gross_salary);

    if (gross_salary>10000)
    {allowance=gross_salary*0.10;
    printf("Allowance:%f\n", gross_salary);

    deduction=gross_salary*0.03;
    printf("Deduction:%f\n", deduction);

    net_salary=gross_salary+allowance-deduction;
    printf("Net Salary:%f\n", net_salary);}

    else {if(gross_salary>5000)
    {allowance=gross_salary*0.07;
    printf("Allowance:%f\n", gross_salary);

    deduction=gross_salary*0.02;
    printf("Deduction:%f\n", deduction);

    net_salary=gross_salary+allowance-deduction;
    printf("Net Salary:%f\n", net_salary);}

    else
    {allowance=0;
     deduction=0;}}


}
