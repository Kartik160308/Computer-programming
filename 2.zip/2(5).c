#include<stdio.h>
void main()

{
    float netsales,grosssales;
    printf("Enter Gross sales:");
    scanf("%f", &grosssales);

    if (grosssales > 20000)
        {netsales=grosssales-grosssales*0.15;
    printf("Net Sales:%f\n", netsales);}

    else if (grosssales > 10000)

           {netsales=grosssales-grosssales*0.10;
    printf("Net sales:%f\n", netsales);}

    else
        {netsales=grosssales-grosssales*0.05;
        printf("Net Sales:%f\n", netsales);}
}

