#include<stdio.h>
void main()

{
    int grams,kgs;
    printf("Enter kg:");
    scanf("%d", &kgs);
    grams=kgs*1000;
    printf("In grams:%d\n", grams);
}
