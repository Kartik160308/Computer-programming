#include<stdio.h>
void main()

{
    int minutes, hours;
    printf("Enter Minutes:");
    scanf("%d", &minutes);
    hours= minutes/60;
    printf("Hours: %d\n", hours);

}
