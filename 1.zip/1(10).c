#include<stdio.h>
void main()

{
    float dollars, pounds;
    printf("Enter Dollars:");
    scanf("%f", &dollars);
    pounds=dollars*0.68;
    printf("Pounds: %f\n", pounds);

}
