#include<stdio.h>
void main()

{
    float celsius, fahrenheit;
    printf("Enter Fahrenheit:");
    scanf("%f", &fahrenheit);
    celsius=(5/9*fahrenheit)+32;
    printf("In Celsius:%f\n", celsius);

}

