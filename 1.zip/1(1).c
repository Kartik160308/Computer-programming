#include<stdio.h>
void main()

{
    int a,b,c;
    printf("Enter Two Number:");
    scanf("%d %d", &a,&b);
    c=a+b;
    printf("c=%d",c);


}
