#include<stdio.h>
int main()

{
    int a1,b1,c1,a2,b2,c2,a3,b3,c3,a4,b4,c4;
    printf("Enter Two Number:");
    scanf("%d %d", &a1,&b1);
    c1=a1+b1;
    printf("Total: %d\n", c1);

    printf("Enter Two Number:");
    scanf("%d %d", &a2,&b2);
    c2=a2*b2;
    printf("Multiplication: %d\n", c2);

    printf("Enter Two Number:");
    scanf("%d %d", &a3,&b3);
    c3=a3-b3;
    printf("Subraction:%d\n", c3);

    printf("Enter Two Number:");
    scanf("%d %d", &a4,&b4);
    c4=a4/b4;
    printf("Divide:%d\n", c4);





}
