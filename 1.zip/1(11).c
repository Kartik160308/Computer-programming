#include<stdio.h>
void main()

{
    int grams,kgs;
    printf("Enter Grams:");
    scanf("%d", &grams);
    kgs=grams/1000;
    printf("In kg:%d\n", kgs);
}
