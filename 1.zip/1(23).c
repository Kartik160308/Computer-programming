#include<stdio.h>
void main()

{
    float sub1,sub2,sub3,total,avg;
    printf("Enter Marks Of Three Subjects:");
    scanf("%f %f %f", &sub1,&sub2,&sub3);

    total=sub1+sub2+sub3;
    printf("Total:%f\n", total);

    avg=total/3;
    printf("Average:%f\n", avg);


}
