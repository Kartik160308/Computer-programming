#include<stdio.h>
void main()

{
    float a,b,c;
    printf("Enter Two NUmber:");
    scanf("%f %f", &a,&b);
    c=a/b;
    printf("Divede:%f\n", c);

}
