#include<stdio.h>
void main()

{
    float radius;
    printf("Enter Radius:");
    scanf("%f", &radius);

    radius=22/7*radius*radius;

    printf("Area: %f\n", radius);


}

