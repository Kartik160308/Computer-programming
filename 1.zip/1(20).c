#include<stdio.h>
void main()

{
    float height, length, area;
    printf("Enter Length and Height:");
    scanf("%f %f", &length, &height);

    area=length*height/2;

    printf("Area: %f\n", area);


}
