#include<stdio.h>
void main()

{
    float celsius, fahrenheit;
    printf("Enter Celsius:");
    scanf("%f", &celsius);
    fahrenheit=(9/5*celsius)+32;
    printf("In Fehrenheit:%f\n", fahrenheit);

}
