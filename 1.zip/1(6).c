#include<stdio.h>
void main()

{
    int minutes, hours;
    printf("Enter Hours:");
    scanf("%d", &hours);
    minutes= hours*60;
    printf("Minutes: %d\n", minutes);

}
