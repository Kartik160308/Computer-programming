#include<stdio.h>
void main()

{
    int dollars, rupees;
    printf("Enter Dollars:");
    scanf("%d", &dollars);
    rupees=dollars*48;
    printf("Ruppes: %d\n", rupees);

}
