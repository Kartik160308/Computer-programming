#include<stdio.h>
void main()

{
    int dollars, rupees;
    printf("Enter Rupees:");
    scanf("%d", &rupees);
    dollars=rupees/48;
    printf("Dollars: %d\n", dollars);

}
